PL/pgSQL Profiler module and command line tool
==============================================

This is the Python module and command line tool to
control the PL/pgSQL Profiler extension for PostgreSQL.

Please visit https://github.com/bigsql/plprofiler for
the main project.
